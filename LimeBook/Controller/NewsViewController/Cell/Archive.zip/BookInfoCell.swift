//
//  BookInfoCell.swift
//  LimeBook
//
//  Created by Lê Dũng on 9/30/18.
//  Copyright © 2018 limerence. All rights reserved.
//

import UIKit
protocol BookInfoCellDelegate {
    func bookInfoExten(_ indexPath : IndexPath)
    func bookInfoUpdate(_ indexPath : IndexPath)
    func commentViewRequestUserInterfaceFocusView(_ sender : Any?)

}
class BookInfoCell: UITableViewCell, BookReactViewDelegate,CommentViewDelegate{
    func didExpandLabel(_ label: ExpandableLabel) {
        
    }
    
    func didCollapseLabel(_ label: ExpandableLabel) {
        
    }
    
    
    func reactViewDidLike() {
        let request = BookLike_Request()
        request.book_id = self.book.id
        if(self.book.is_like)
        {
            request.is_like = false ;
        }
        else
        {
            request.is_like = true
        }
        
        request.user_id = userInstance.user.id
        services.bookLike(request, success: { (response) in
            self.book.updateReact(response)
            self.reactBar.set(self.book)
        }) { (errlr) in
        }

    }
    @IBOutlet weak var externalView2: UIView!
    @IBOutlet weak var externallHeight2: NSLayoutConstraint!
    
    @IBOutlet weak var extenalView: UIView!
    @IBOutlet weak var extenalHeight: NSLayoutConstraint!
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var reactBar: ReactBarView!
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbDes: UILabel!
    var delegate : BookInfoCellDelegate!
    var indexPath : IndexPath!
    var book : Book!
    let queue = SerialOperationQueue()

    
    var bookInfoView = BookInfoView()
    var bookCommentView = CommentView()
    @IBOutlet weak var innerView: GCleanView!
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = template.backgroundColor
        selectionStyle = .none
        reactBar.delegate = self;
        mainView.drawRadius(4)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func set(_ book : Book, _ indexPath : IndexPath)
    {
        self.book = book
        self.bookCommentView.book = self.book
        self.indexPath = indexPath
        bookCommentView.delegate = self;
        self.updateData()

        if(book.canDraw)
        {
            self.drawProcess()
        }
    }
    
    func drawProcess()
    {
        if(book.isDrawExtenal)
        {
            drawExtenal()
        }
        else
        {
            clearExtenal()
        }

        if(book.isDrawExtenalComment)
        {
            drawExtenalComment()
        }
        else
        {
            clearExtenalComment()
        }
    }
    
    func commentViewRequestUserInterfaceFocusView(_ sender: Any?) {
        delegate.commentViewRequestUserInterfaceFocusView(sender)
    }
    func updateData()
    {
        bookInfoView.set(self.book)
        reactBar.set(book)
        lbName.text = book.title
        lbDes.attributedText = self.book.getAttributeDetail()
        
    }

    func drawExtenal()
    {
        extenalView.removeSubsView()
        extenalView.addSubview(bookInfoView)
        extenalView.setLayout(bookInfoView)
    }
    
    func clear()
    {
        clearExtenal()
        clearExtenalComment()
    }
    func clearExtenal()
    {
        extenalView.removeSubsView()
        extenalHeight.constant = 0.0
    }
    
    func drawExtenalComment()
    {
        self.externalView2.removeSubsView()
        self.externalView2.addSubview(self.bookCommentView)
        self.externalView2.setLayout(self.bookCommentView)
    }
    
    func clearExtenalComment()
    {
        externalView2.removeSubsView()
        externallHeight2.constant = 0.0
        bookCommentView.clear()
    }

    func reactViewComment() {
        
        book.isDrawExtenalComment = !book.isDrawExtenalComment
        
        if(book.isDrawExtenalComment)
        {
            book.isDrawExtenal = false;
        }
        drawProcess()
        book.canDraw = false ;
        if(book.isDrawExtenalComment)
        {
            bookCommentView.loadComment {
                self.delegate.bookInfoExten(self.indexPath)
            }
        }
        else
        {
            self.delegate.bookInfoExten(self.indexPath)
        }
    }

    func reactViewDidTouchDetail()
    {
        book.isDrawExtenal = !book.isDrawExtenal
        
        if(book.isDrawExtenal)
        {
            book.isDrawExtenalComment = false;
        }
        drawProcess()
        book.canDraw = false ;
        delegate.bookInfoExten(self.indexPath)
    }

    
    func commentViewRequestUserInterface() {
        delegate.bookInfoUpdate(self.indexPath)
    }
    
    
    
}
