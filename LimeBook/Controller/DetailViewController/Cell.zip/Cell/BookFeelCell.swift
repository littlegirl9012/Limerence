//
//  BookFeelCell.swift
//  LimeBook
//
//  Created by Lê Dũng on 10/14/18.
//  Copyright © 2018 limerence. All rights reserved.
//

import UIKit

class BookFeelCell: UITableViewCell {

    @IBOutlet weak var mainView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var lbTitle: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lbNote: UILabel!
    @IBOutlet weak var lbContent: UILabel!
    @IBOutlet weak var userImageView: UserImageView!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        contentView.backgroundColor = template.backgroundColor
        mainView.backgroundColor = UIColor.white
    }
    
    func set(_ value : Feelling)
    {
        lbTitle.text = value.aliasname
        userImageView.set(value.aliasname, url: value.avatar)
        lbContent.attributedText = value.attributeContent
        lbNote.attributedText = value.attributeNote
        let url = URL.init(string: value.image)
        if(url != nil)
        {
            imgView.af_setImage(withURL: url!)
        }
        else
        {
            imgView.image = nil
        }

    }
    
}
